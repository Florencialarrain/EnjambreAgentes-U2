// Clase 20/10 · Tu enjambre lee · Florencia Larraín
// Lee temperatura real de Santiago (Open-Meteo) y la transforma en una señal 0–1.
// Entre 0 y 35 °C, el radio de vecindad aumenta de 40 a 160; fuera de ese rango se limita.
// Antes de recibir datos usa señal 0.5. Si falla internet usa una copia real guardada.
// No predice el clima: es una regla visual elegida para explorar el comportamiento del enjambre.
// Adaptación del código del equipo con apoyo de Codex.
const direccion = 'https://api.open-meteo.com/v1/forecast?latitude=-33.45&longitude=-70.66&current=temperature_2m&timezone=America%2FSantiago';
let datos = null;
let senal = 0.5;
let estado = 'Esperando datos: señal neutra';
let origen = 'Sin datos';
let modo = 'vivo';
let versionCarga = 0;
let textoEstado;

let n = 40;
let r = 90;
let k = 0.02;
let semilla = 5;
let verRadio = false;
let cuadroCaptura = 0; // 300 para comparar; 0 para animación continua.
let agentes = [];
let cuadro = 0;

function setup() {
  createCanvas(600, 400);
  reiniciar();
  textoEstado = createP(estado);
  const vivo = createButton('Leer de internet');
  vivo.mousePressed(() => { modo = 'vivo'; cargarDatos(); });
  const respaldo = createButton('Usar respaldo');
  respaldo.mousePressed(() => { modo = 'respaldo'; cargarDatos(); });
  cargarDatos();
  setInterval(() => { if (modo === 'vivo') cargarDatos(); }, 15 * 60 * 1000);
}

// Recupera exactamente las mismas condiciones para comparar radios.
function reiniciar() {
  randomSeed(semilla);
  agentes = [];
  cuadro = 0;
  for (let i = 0; i < n; i++) agentes.push(crearAgente());
  loop();
}

function draw() {
  background(255);
  senal = leerSenal();
  r = lerp(40, 160, senal);
  for (let a of agentes) {
    let vs = vecinosDe(a, agentes, r);
    acercarAPromedio(a, vs, k);
    mover(a);
    aplicarBorde(a);
  }
  // Dibuja todos los lazos antes de dibujar los círculos encima.
  for (let a of agentes) dibujarLazos(a, vecinosDe(a, agentes, r));
  for (let a of agentes) mostrar(a, vecinosDe(a, agentes, r).length > 0);
  if (verRadio && agentes.length > 0) mostrarRadio(agentes[0], r);
  fill(0);
  noStroke();
  text('Temperatura → radio | Señal: ' + senal.toFixed(3) + ' | Radio: ' + r.toFixed(0), 10, 20);
  text('Frío: menor radio · Calor: mayor radio · R: reiniciar', 10, 38);
  cuadro++;
  if (cuadroCaptura > 0 && cuadro === cuadroCaptura) noLoop();
}

// Devuelve posición, velocidad y tamaño iniciales.
function crearAgente() {
  return {x: random(width), y: random(height), vx: random(-2, 2), vy: random(-2, 2), d: random(8, 16)};
}
function esVecino(a, b, radio) {
  return a !== b && dist(a.x, a.y, b.x, b.y) < radio;
}
function vecinosDe(a, todos, radio) {
  let vs = [];
  for (let b of todos) if (esVecino(a, b, radio)) vs.push(b);
  return vs;
}
// Cambia la posición hacia el promedio; un agente solo conserva su posición.
function acercarAPromedio(a, vs, intensidad) {
  if (vs.length === 0) return;
  let px = 0;
  let py = 0;
  for (let b of vs) { px += b.x; py += b.y; }
  a.x = lerp(a.x, px / vs.length, intensidad);
  a.y = lerp(a.y, py / vs.length, intensidad);
}
function mover(a) { a.x += a.vx; a.y += a.vy; }
function aplicarBorde(a) {
  if (a.x > width - a.d / 2) { a.x = width - a.d / 2; a.vx *= -1; }
  if (a.x < a.d / 2) { a.x = a.d / 2; a.vx *= -1; }
  if (a.y > height - a.d / 2) { a.y = height - a.d / 2; a.vy *= -1; }
  if (a.y < a.d / 2) { a.y = a.d / 2; a.vy *= -1; }
}
function dibujarLazos(a, vs) {
  stroke(200);
  for (let b of vs) line(a.x, a.y, b.x, b.y);
}
function mostrar(a, tieneVecinos) {
  stroke(0);
  if (tieneVecinos) fill(230, 60, 60);
  else fill(255);
  circle(a.x, a.y, a.d);
}
function mostrarRadio(a, radio) {
  noFill();
  stroke(0);
  circle(a.x, a.y, radio * 2);
}
function keyPressed() {
  if (key === 'r' || key === 'R') reiniciar();
}

function temperaturaDe(json) {
  const valor = json?.current?.temperature_2m;
  if (typeof valor !== 'number' || !Number.isFinite(valor)) {
    throw new Error('Temperatura ausente o inválida');
  }
  if (typeof json.current.time !== 'string') throw new Error('Falta fecha del dato');
  return valor;
}

function leerSenal() {
  if (datos === null) return 0.5;
  return constrain(temperaturaDe(datos) / 35, 0, 1);
}

function mostrarEstado() {
  if (textoEstado) textoEstado.elt.textContent = estado;
}

async function pedirJSON(url) {
  const control = new AbortController();
  const limite = setTimeout(() => control.abort(), 8000);
  try {
    const respuesta = await fetch(url, {signal: control.signal});
    if (!respuesta.ok) throw new Error('HTTP ' + respuesta.status);
    const json = await respuesta.json();
    temperaturaDe(json);
    return json;
  } finally {
    clearTimeout(limite);
  }
}

async function cargarDatos() {
  const version = ++versionCarga;
  estado = datos === null ? 'Esperando datos: señal neutra 0.5' : 'Actualizando; se conserva el dato anterior';
  mostrarEstado();
  let nuevos;
  let nuevaFuente;
  try {
    if (modo === 'respaldo') {
      nuevos = await pedirJSON('respaldo/clima.json');
      nuevaFuente = 'Respaldo local';
    } else {
      try {
        nuevos = await pedirJSON(direccion);
        nuevaFuente = 'Internet';
      } catch (error) {
        if (version !== versionCarga) return;
        nuevos = await pedirJSON('respaldo/clima.json');
        nuevaFuente = 'Respaldo automático (falló internet)';
      }
    }
    if (version !== versionCarga) return;
    datos = nuevos;
    origen = nuevaFuente;
    estado = origen + ' · Santiago · ' + temperaturaDe(datos) + ' °C · Fecha del dato: ' +
      datos.current.time.replace('T', ' ') + ' (hora de Santiago) · Open-Meteo';
    mostrarEstado();
  } catch (error) {
    if (version !== versionCarga) return;
    estado = datos === null ? 'Sin datos disponibles: el enjambre continúa con señal neutra 0.5' :
      'No se pudo actualizar; se conserva ' + origen + ' · ' + datos.current.time;
    mostrarEstado();
  }
}
