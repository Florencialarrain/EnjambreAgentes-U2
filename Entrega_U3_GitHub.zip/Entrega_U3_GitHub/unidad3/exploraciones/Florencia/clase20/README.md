# Clase 20/10 — Tu enjambre lee
Florencia Larraín

## Exploración
La temperatura de Santiago controla el radio de vecindad del enjambre del equipo. La señal es temperatura / 35, limitada a 0–1. El radio se interpola entre 40 y 160. El cambio de radio afecta a qué agentes se acercan entre sí; el movimiento y los rebotes originales se conservan.

Esta correspondencia es una decisión visual, no una explicación física de cómo el clima afecta a las personas.

## Funcionamiento
Antes de que llegue la primera respuesta se usa 0.5 (radio 100). La carga es asíncrona, fuera de preload, por lo que el primer cuadro no depende de la red. Se actualiza cada 15 minutos. Si falla internet o la respuesta es inválida, se usa respaldo/clima.json; si también falla ese archivo, sigue la animación con señal neutra o con el último dato válido. Los botones permiten comparar internet y respaldo. R reinicia los agentes con la misma semilla.

Se muestran origen, temperatura y fecha del dato en hora de Santiago. Esto ayuda a distinguir un dato actual de una copia antigua y evita presentar el respaldo como tiempo real.

## Fuente y respaldo
API: https://api.open-meteo.com/v1/forecast?latitude=-33.45&longitude=-70.66&current=temperature_2m&timezone=America%2FSantiago
Respaldo real conservado de la exploración anterior: Open-Meteo, descargado 20/10/2026 17:33 UTC; dato del 20/10/2026 14:30 hora de Santiago: 16.9 °C. Se conserva el JSON original, que también incluye viento; esta exploración usa únicamente temperatura.

## Abrir
Desde esta carpeta ejecutar `python3 -m http.server 8020` y abrir http://localhost:8020/. También se puede usar Live Server en VS Code. Requiere internet para cargar p5.js desde CDN; el respaldo permite prescindir de la API una vez cargada la librería.

Código basado en el enjambre del equipo, adaptado con apoyo de Codex. La clase 15/10 se conserva por separado en exploraciones/Florencia/.
