// Clase 15/10 · Tu enjambre mira · Florencia Larraín
// La cámara aporta el brillo promedio RGB de toda la imagen, normalizado entre 0 y 1.
// Con poca luz aumenta el radio de vecindad y los agentes se agrupan más;
// con mucha luz disminuye. Una imagen negra produce 0 y el enjambre sigue moviéndose.
// No reconoce personas, rostros ni objetos; no graba ni envía imágenes.
// Adaptación del enjambre del equipo con apoyo de Codex.
let video;
let senal = 0;
let estadoCamara = 'Esperando cámara';
let camaraSolicitada = false;

let n = 40;
let r = 90;
let k = 0.02;
let semilla = 5;
let verRadio = false;
let cuadroCaptura = 0; // 300 para comparar; 0 para animación continua.
let agentes = [];
let cuadro = 0;

function setup() {
  createCanvas(600, 400);
  reiniciar();
  const boton = createButton('Activar cámara');
  boton.mousePressed(iniciarCamara);
}

// Recupera exactamente las mismas condiciones para comparar radios.
function reiniciar() {
  randomSeed(semilla);
  agentes = [];
  cuadro = 0;
  for (let i = 0; i < n; i++) agentes.push(crearAgente());
  loop();
}

function draw() {
  background(255);
  senal = leerSenal();
  r = lerp(160, 40, senal);
  for (let a of agentes) {
    let vs = vecinosDe(a, agentes, r);
    acercarAPromedio(a, vs, k);
    mover(a);
    aplicarBorde(a);
  }
  // Dibuja todos los lazos antes de dibujar los círculos encima.
  for (let a of agentes) dibujarLazos(a, vecinosDe(a, agentes, r));
  for (let a of agentes) mostrar(a, vecinosDe(a, agentes, r).length > 0);
  if (verRadio && agentes.length > 0) mostrarRadio(agentes[0], r);
  fill(0);
  noStroke();
  text('Luz: ' + senal.toFixed(3) + ' | Radio: ' + r.toFixed(0), 10, 20);
  text(estadoCamara + ' | R: reiniciar', 10, 38);
  cuadro++;
  if (cuadroCaptura > 0 && cuadro === cuadroCaptura) noLoop();
}

// Devuelve posición, velocidad y tamaño iniciales.
function crearAgente() {
  return {x: random(width), y: random(height), vx: random(-2, 2), vy: random(-2, 2), d: random(8, 16)};
}
function esVecino(a, b, radio) {
  return a !== b && dist(a.x, a.y, b.x, b.y) < radio;
}
function vecinosDe(a, todos, radio) {
  let vs = [];
  for (let b of todos) if (esVecino(a, b, radio)) vs.push(b);
  return vs;
}
// Cambia la posición hacia el promedio; un agente solo conserva su posición.
function acercarAPromedio(a, vs, intensidad) {
  if (vs.length === 0) return;
  let px = 0;
  let py = 0;
  for (let b of vs) { px += b.x; py += b.y; }
  a.x = lerp(a.x, px / vs.length, intensidad);
  a.y = lerp(a.y, py / vs.length, intensidad);
}
function mover(a) { a.x += a.vx; a.y += a.vy; }
function aplicarBorde(a) {
  if (a.x > width - a.d / 2) { a.x = width - a.d / 2; a.vx *= -1; }
  if (a.x < a.d / 2) { a.x = a.d / 2; a.vx *= -1; }
  if (a.y > height - a.d / 2) { a.y = height - a.d / 2; a.vy *= -1; }
  if (a.y < a.d / 2) { a.y = a.d / 2; a.vy *= -1; }
}
function dibujarLazos(a, vs) {
  stroke(200);
  for (let b of vs) line(a.x, a.y, b.x, b.y);
}
function mostrar(a, tieneVecinos) {
  stroke(0);
  if (tieneVecinos) fill(230, 60, 60);
  else fill(255);
  circle(a.x, a.y, a.d);
}
function mostrarRadio(a, radio) {
  noFill();
  stroke(0);
  circle(a.x, a.y, radio * 2);
}
// El botón pide acceso a la cámara solamente cuando lo presionas.
function iniciarCamara() {
  if (camaraSolicitada) return;
  camaraSolicitada = true;
  estadoCamara = 'Esperando permiso de cámara';
  try {
    video = createCapture({video: true, audio: false}, () => {
      estadoCamara = 'Cámara activa';
      const pista = video.elt.srcObject.getVideoTracks()[0];
      if (pista) pista.addEventListener('ended', () => {
        estadoCamara = 'Cámara desconectada';
      });
    });
    video.size(80, 60);
    video.hide();
    video.elt.addEventListener('error', () => {
      estadoCamara = 'Cámara no disponible';
    });
    // p5 comunica el rechazo por su promesa interna; este aviso también
    // cubre permisos pendientes, bloqueados o una cámara sin fotogramas.
    setTimeout(() => {
      if (!video.elt.srcObject) {
        estadoCamara = 'Sin cámara: revisa el permiso y recarga';
      }
    }, 10000);
  } catch (error) {
    estadoCamara = 'Cámara no disponible: revisa el permiso y recarga';
  }
}

function leerSenal() {
  if (!video || video.elt.readyState < 2 ||
      !video.elt.srcObject || !video.elt.srcObject.active) return 0;
  video.loadPixels();
  return normalizarBrillo(video.pixels);
}

// Divide por una constante: nunca por el brillo medido, que podría ser cero.
function normalizarBrillo(pixeles) {
  let suma = 0;
  const cantidad = Math.floor(pixeles.length / 4);
  if (cantidad === 0) return 0;
  for (let i = 0; i < cantidad * 4; i += 4) {
    suma += (pixeles[i] + pixeles[i + 1] + pixeles[i + 2]) / 3;
  }
  return constrain(suma / (cantidad * 255), 0, 1);
}

function keyPressed() {
  if (key === 'r' || key === 'R') reiniciar();
}
