# Clase 15/10 — Tu enjambre mira

Florencia Larraín. Exploración individual basada en el enjambre del equipo.

## Uso en p5.js
Crear una copia del proyecto del equipo en editor.p5js.org, reemplazar sketch.js por sketch.js y ejecutar. Presionar «Activar cámara» y permitir el acceso si se desea probar la cámara real. No se solicita audio.

## Uso local
Desde la raíz del repositorio, iniciar `python3 -m http.server 8000` y abrir http://localhost:8000/exploraciones/Florencia/. Requiere internet para cargar p5.js. Utilizar localhost o HTTPS para acceder a la cámara.

## Exploración
La cámara se lee a 80 × 60. Se promedian los canales RGB de todos los píxeles y se divide por 255. La señal va de 0 a 1: negro = 0, blanco = 1. Con poca luz el radio aumenta hasta 160; con mucha luz baja hasta 40. Los 40 agentes conservan movimiento, rebote y acercamiento a vecinos del código base. R reinicia los agentes.

No se reconocen personas ni objetos, ni se guardan o envían imágenes. Sin fotogramas se usa 0 como respaldo; el texto diferencia ese estado de una cámara activa con imagen negra.

## Comprobación manual
Activar la cámara; observar el valor de luz y el radio. Tapar la lente: la señal debe acercarse a 0, el radio a 160 y el movimiento continuar. Iluminar: la señal sube y el radio baja. La exposición automática de la cámara puede afectar la magnitud del cambio.

La ejecución se comprobó en el navegador: animación activa sin errores de consola y respaldo 0 al faltar cámara. El navegador integrado no habilitó la cámara física; esa comprobación queda pendiente en un navegador con acceso a cámara. Las comprobaciones automáticas verifican la normalización y el comportamiento del radio con píxeles simulados.

Exploración individual agregada al historial del repositorio del equipo. La publicación remota está pendiente de iniciar sesión en TutorMaker.
