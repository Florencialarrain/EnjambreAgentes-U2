# Entrega Unidad 3 para GitHub

El informe se encuentra en Informe Unidad 3.docx. El sistema se ejecuta abriendo unidad3/index.html con Live Server.

Destino indicado: https://github.com/Florencialarrain/EnjambreAgentes-U2 . Agregar la carpeta unidad3 y el informe conservando los archivos de Unidad 2. La etiqueta prevista u3-entrega-revision1 solo se considerará publicada cuando sea visible en GitHub.

Las pruebas técnicas y la comparación de fallas están incluidas. El informe mantiene las limitaciones de evidencia: aportes individuales no acreditados, prueba externa no registrada y falta de una predicción previa documentada. No son resultados que puedan deducirse de las pruebas automáticas.
